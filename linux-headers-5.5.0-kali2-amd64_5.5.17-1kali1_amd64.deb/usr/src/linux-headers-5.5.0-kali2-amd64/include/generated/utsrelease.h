#define UTS_RELEASE "5.5.0-kali2-amd64"
