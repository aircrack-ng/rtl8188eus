#define LINUX_PACKAGE_ID " Debian 5.5.17-1kali1"
