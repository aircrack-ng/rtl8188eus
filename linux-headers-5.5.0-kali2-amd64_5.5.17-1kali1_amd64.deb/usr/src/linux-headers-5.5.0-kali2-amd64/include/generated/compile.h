/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP Debian 5.5.17-1kali1 (2020-04-21)"
#define LINUX_COMPILE_BY "devel"
#define LINUX_COMPILE_HOST "kali.org"
#define LINUX_COMPILER "gcc version 9.3.0 (Debian 9.3.0-10)"
